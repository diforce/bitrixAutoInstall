<?
/* make trans_check.pl happy
GetMessage('OP_NAME_CLOUDS_BROWSE');
GetMessage('OP_NAME_CLOUDS_UPLOAD');
GetMessage('OP_NAME_CLOUDS_CONFIG');
*/
?>
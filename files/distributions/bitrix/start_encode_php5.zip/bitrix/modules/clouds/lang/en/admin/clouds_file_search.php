<?
$MESS["CLO_STORAGE_SEARCH_TITLE"] = "Select file in cloud storage";
$MESS["CLO_STORAGE_SEARCH_BUCKET"] = "Cloud storage";
$MESS["CLO_STORAGE_SEARCH_CHOOSE_BUCKET"] = "Select cloud storage";
$MESS["CLO_STORAGE_SEARCH_PATH"] = "Path";
$MESS["CLO_STORAGE_SEARCH_NAME"] = "Name";
$MESS["CLO_STORAGE_SEARCH_SIZE"] = "Size";
$MESS["CLO_STORAGE_SEARCH_LIST_ERROR"] = "Error getting file list.";
?>
<?
$MESS["CLO_STORAGE_OPENSTACK_EMPTY_HOST"] = "The server name is now specified.";
$MESS["CLO_STORAGE_OPENSTACK_EMPTY_USER"] = "The user name is not specified.";
$MESS["CLO_STORAGE_OPENSTACK_EMPTY_KEY"] = "The access key is not specified.";
$MESS["CLO_STORAGE_OPENSTACK_ERROR_GET_TOKEN"] = "Authorization error. Please check the settings.";
$MESS["CLO_STORAGE_OPENSTACK_EDIT_USER"] = "User name (API user)";
$MESS["CLO_STORAGE_OPENSTACK_EDIT_KEY"] = "Access key (API key)";
$MESS["CLO_STORAGE_OPENSTACK_EDIT_HOST"] = "Server name (API host)";
?>
<?
$MESS["TASK_NAME_CLOUDS_DENIED"] = "Access denied";
$MESS["TASK_NAME_CLOUDS_BROWSE"] = "Select files";
$MESS["TASK_NAME_CLOUDS_UPLOAD"] = "Move files";
$MESS["TASK_NAME_CLOUDS_FULL_ACCESS"] = "Full access";
$MESS["TASK_DESC_CLOUDS_DENIED"] = "Access denied";
$MESS["TASK_DESC_CLOUDS_BROWSE"] = "Browse cloud storages";
$MESS["TASK_DESC_CLOUDS_UPLOAD"] = "Upload new files from Site Explorer and download existing files";
$MESS["TASK_DESC_CLOUDS_FULL_ACCESS"] = "Full access to files and settings.";
?>
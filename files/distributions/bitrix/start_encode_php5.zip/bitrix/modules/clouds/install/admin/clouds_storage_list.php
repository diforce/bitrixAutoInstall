<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/clouds/admin/clouds_storage_list.php");
?>

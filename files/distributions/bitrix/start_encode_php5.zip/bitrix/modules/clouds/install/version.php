<?
$arModuleVersion = array(
	"VERSION" => "12.0.5",
	"VERSION_DATE" => "2013-03-07 14:00:00"
);
?>
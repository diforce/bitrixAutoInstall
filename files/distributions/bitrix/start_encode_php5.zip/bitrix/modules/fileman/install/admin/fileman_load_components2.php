<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/fileman/admin/fileman_load_components2.php");?>

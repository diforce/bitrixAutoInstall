<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/fileman/admin/fileman_spell_addWord.php");
?>
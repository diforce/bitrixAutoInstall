<?

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/fileman/admin/fileman_menu_edit.php");?>

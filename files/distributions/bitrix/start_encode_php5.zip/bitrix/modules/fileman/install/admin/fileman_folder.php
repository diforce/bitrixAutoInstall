<?

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/fileman/admin/fileman_folder.php");?>

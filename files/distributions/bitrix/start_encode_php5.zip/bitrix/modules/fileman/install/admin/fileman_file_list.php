<?

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/fileman/admin/fileman_file_list.php");?>
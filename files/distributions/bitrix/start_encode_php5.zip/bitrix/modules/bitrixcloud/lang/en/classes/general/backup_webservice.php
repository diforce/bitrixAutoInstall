<?
$MESS["BCL_BACKUP_WS_SERVER"] = "Error sending request to the backup server (code: #STATUS#).";
?>
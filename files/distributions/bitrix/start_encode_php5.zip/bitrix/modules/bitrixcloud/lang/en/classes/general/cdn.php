<?
$MESS["BCL_CDN_NOTIFY"] = "Web Accelerator (CDN) has been disabled attempting to update the configuration. Use the <a href=\"#HREF#\">settings form</a> to enable it back.";
$MESS["BCL_CDN_AI_SETT"] = "Configure CDN";
$MESS["BCL_CDN_AI_TITLE"] = "CDN Web Accelerator";
$MESS["BCL_CDN_AI_USAGE_TOTAL"] = "Total:";
$MESS["BCL_CDN_AI_USAGE_AVAIL"] = "Available:";
$MESS["BCL_CDN_AI_TURN_ON"] = "Enable acceleration";
$MESS["BCL_CDN_AI_IS_OFF"] = "Disabled.";
?>
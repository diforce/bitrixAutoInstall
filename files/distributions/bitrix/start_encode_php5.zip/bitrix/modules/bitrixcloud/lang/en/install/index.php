<?
$MESS["BCL_MODULE_NAME"] = "Bitrix Cloud Service";
$MESS["BCL_MODULE_DESCRIPTION"] = "Provides backup storage, CDN and cloud storage features.";
$MESS["BCL_INSTALL_TITLE"] = "Bitrix Cloud Services Installation";
$MESS["BCL_UNINSTALL_TITLE"] = "Bitrix Cloud Services Uninstallation";
?>
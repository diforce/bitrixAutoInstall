<?

$bitrixcloud_default_option = array(
	"cdn_policy_url" => "http://www.1c-bitrix.ru/buy_tmp/cdn.php",
	"backup_policy_url" => "http://www.1c-bitrix.ru/buy_tmp/backup.php",
);
?>
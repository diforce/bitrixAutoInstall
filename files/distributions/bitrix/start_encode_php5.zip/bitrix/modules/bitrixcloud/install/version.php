<?
$arModuleVersion = array(
	"VERSION" => "12.5.0",
	"VERSION_DATE" => "2013-03-25 14:30:00",
);
?>
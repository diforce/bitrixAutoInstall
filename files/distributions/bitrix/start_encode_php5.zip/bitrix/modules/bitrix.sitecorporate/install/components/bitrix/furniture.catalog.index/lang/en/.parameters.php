<?
$MESS["IBLOCK_TYPE"] = "Information Block Type";
$MESS["IBLOCK_IBLOCK"] = "Information Block";
$MESS["IBLOCK_BINDING"] = "Show";
$MESS["IBLOCK_BINDING_SECTION"] = "sections";
$MESS["IBLOCK_BINDING_ELEMENT"] = "elements";
$MESS["IBLOCK_ANY"] = "(any)";
$MESS["CP_BPR_CACHE_GROUPS"] = "Regard Access Permission";
?>
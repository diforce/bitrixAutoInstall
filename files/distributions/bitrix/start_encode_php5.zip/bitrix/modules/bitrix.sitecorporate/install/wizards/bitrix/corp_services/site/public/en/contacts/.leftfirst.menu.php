<?
$aMenuLinks = Array(
	Array(
		"Contacts", 
		"./", 
		Array(), 
		Array(), 
		"" 
	),
);
?>
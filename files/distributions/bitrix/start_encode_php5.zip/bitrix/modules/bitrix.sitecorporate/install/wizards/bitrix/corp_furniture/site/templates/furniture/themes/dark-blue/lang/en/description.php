<?
$MESS["CFST_THEME_DARK_BLUE"] = "Indigo";
?>
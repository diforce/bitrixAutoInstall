<?
$sSectionName = "Authorization";
$arDirProperties = array(

);
?>
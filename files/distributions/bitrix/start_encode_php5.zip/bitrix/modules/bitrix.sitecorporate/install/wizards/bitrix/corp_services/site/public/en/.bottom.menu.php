<?
$aMenuLinks = Array(
	Array(
		"Site map", 
		"search/map.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Contacts", 
		"contacts/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Login", 
		"auth.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>
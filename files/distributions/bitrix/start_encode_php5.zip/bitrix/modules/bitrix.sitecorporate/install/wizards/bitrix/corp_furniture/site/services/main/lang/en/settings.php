<?
$MESS["MAIN_OPT_DESCRIPTION"] = "Page description";
$MESS["MAIN_OPT_KEYWORDS"] = "Keywords";
$MESS["MAIN_OPT_TITLE"] = "Browser window caption";
$MESS["MAIN_OPT_KEYWORDS_INNER"] = "Promotion keywords";
?>
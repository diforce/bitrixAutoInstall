<p>&copy; 2001-2012 &laquo;Company name&raquo;</p>
<p>Castlemilk, Glasgow</p>
<p><b>Phone: X.XXX.XXX.XXXX</b></p>

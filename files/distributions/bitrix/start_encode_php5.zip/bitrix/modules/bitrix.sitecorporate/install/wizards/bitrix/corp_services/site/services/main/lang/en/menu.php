<?
$MESS["WIZ_MENU_LEFT_DEFAULT"] = "Section menu";
$MESS["WIZ_MENU_LEFT"] = "Section menu (sub-levels)";
$MESS["WIZ_MENU_LEFT_FIRST"] = "Section menu (top level)";
$MESS["WIZ_MENU_TOP"] = "Site menu";
$MESS["WIZ_MENU_BOTTOM"] = "Bottom menu";
?>
<?
$sSectionName = "Personal";
$arDirProperties = Array(

);
?>
<?
$MESS["SHOW_PICTURE_DETAIL"] = "Show Image";
?>
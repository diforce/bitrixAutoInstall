<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("About J&V");
?>
<p>J&V has been operating since 1993. Today J&V is a universal bank providing local and international, corporate and private clients with a broad range of financial services, comprising corporate finance and advisory, sales, trading, transaction banking as well as private wealth management and asset management services.
</p>
 									
<p>J&V has 4,5 million retail customers and 250,000 corporate customers, with 230 branches in Europe and in the Baltic countries and 40 branches in Russia.</p>
 									Among the services provided:									
<ul> 									
  <li>Bank cards;</li>
 									
  <li>Savings & CD Accounts;</li>
 									
  <li>Lending Programs;</li>
 									
  <li>Online Banking;</li>
 									
  <li>Safe Deposit Boxes;</li>
 									
  <li>Merchant Services;</li>
 									
  <li>Trade Services.</li>
 									</ul>
 									
<p>J&V's offices' offer a new format where clients can be serviced with maximum convenience and comfort.</p>
 									
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
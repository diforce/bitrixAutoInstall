<?
$aMenuLinks = Array(
	Array(
		"Personal", 
		"fiz/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Corporate", 
		"corp/", 
		Array(), 
		Array(), 
		"" 
	),
);
?>
<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Designer Profiles");
?>
						 											 						
<table cellspacing="10"> 							
  <tbody>
    <tr> 								<td valign="top" colspan="2">Ryan Appleby</td></tr>
   							
    <tr> 								<td width="20%" valign="top"> 									<img height="200" width="154" src="#SITE_DIR#upload/kolesnikov.jpg" title="Ryan Appleby " alt="Ryan Appleby" /> 								</td> 								<td width="60%" valign="top">French Designer/Studio in Mulhouse, France
        <br /> <br />
       As one of the most well known European designers, Ryan Appleby has won about every award in Europe and the US for seating design.
       </td> 							</tr>
   						</tbody>
</table>				
 						
<table cellspacing="10"> 							
  <tbody>
    <tr> 								<td valign="top" colspan="2"> 									Andrew Allerton							</td> 							</tr>
   							
    <tr> 								<td width="20%" valign="top"> 									<img height="200" width="154" src="#SITE_DIR#upload/horn.jpg" title="Andrew Allerton " alt="Andrew Allerton" /> 								</td> 								<td width="60%" valign="top">German Designer/Studio in Eislingen, Germany
        <br /> <br />
       Andrew' design philosophy is that the better the designer the better the product. Our product is always about design aesthetics and function.</td> 							</tr>
   						</tbody>
</table>
 						
	 						 							
<table cellspacing="10">
  <tbody>
    <tr> 								<td valign="top" colspan="2"> 									Michael Alleine							</td> 							</tr>
   							
    <tr> 								<td width="20%" valign="top"> 									<img height="200" width="154" src="#SITE_DIR#upload/ratchenko.jpg" title="Michael Alleine" alt="Michael Alleine" /> 								</td> 								<td width="60%" valign="top"> 									American Designer 
         <br /><br />
		 The newest designer of Furniture Company is a young American designer who has already worked on many products for the top European manufacturers.</td></tr>
  </tbody>
</table>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
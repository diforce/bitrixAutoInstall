<?
$MESS["SERVICE_MAIN_SETTINGS"] = "Site Settings";
$MESS["SERVICE_IBLOCK"] = "Information Blocks";
?>
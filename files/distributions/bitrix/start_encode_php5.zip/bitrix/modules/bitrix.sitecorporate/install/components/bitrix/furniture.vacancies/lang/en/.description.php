<?
$MESS["SUPPORT_FAQ_EL_COMPONENT_NAME"] = "Vacancies";
$MESS["SUPPORT_FAQ_EL_COMPONENT_DESCRIPTION"] = "Renders the information block contents as a vacancy list.";
$MESS["SUPPORT_FAQ_EL_COMPONENTS"] = "Vacancies";
?>
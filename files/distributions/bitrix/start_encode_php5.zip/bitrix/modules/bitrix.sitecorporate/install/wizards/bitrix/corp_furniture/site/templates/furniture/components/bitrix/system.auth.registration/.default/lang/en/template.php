<?
$MESS["AUTH_REGISTER"] = "Registration";
$MESS["AUTH_NAME"] = "First Name";
$MESS["AUTH_LAST_NAME"] = "Last Name";
$MESS["AUTH_LOGIN_MIN"] = "Login (3 or more characters):";
$MESS["AUTH_PASSWORD_MIN"] = "Password (6 or more characters):";
$MESS["AUTH_CONFIRM"] = "Confirm Password";
$MESS["CAPTCHA_REGF_PROMT"] = "CAPTCHA Code";
$MESS["AUTH_REQ"] = "Required Fields";
$MESS["AUTH_AUTH"] = "Authorization";
$MESS["AUTH_PASSWORD_REQ"] = "Password";
$MESS["AUTH_EMAIL_WILL_BE_SENT"] = "A registration confirmation request will be sent to the specified e-mail address.";
$MESS["AUTH_EMAIL_SENT"] = "A registration confirmation request has been sent to the specified e-mail address.";
?>
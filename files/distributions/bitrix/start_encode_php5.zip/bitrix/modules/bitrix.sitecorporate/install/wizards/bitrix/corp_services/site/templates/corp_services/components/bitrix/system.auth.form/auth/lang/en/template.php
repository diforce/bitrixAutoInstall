<?
$MESS ['AUTH_LOGIN'] = "Login";
$MESS ['AUTH_PASSWORD'] = "Password";
$MESS ['AUTH_REMEMBER_ME'] = "remember me";
$MESS ['AUTH_LOGIN_BUTTON'] = "Log In";
$MESS ['AUTH_REGISTER'] = "Register";
$MESS ['AUTH_REGISTER_DESC'] = "Register here";
$MESS ['AUTH_FORGOT_PASSWORD'] = "Forgot password?";
$MESS ['AUTH_LOGOUT'] = "Log out";
$MESS ['AUTH_PROFILE'] = "My Profile";
$MESS ['AUTH_BLOG'] = "My Blog";
$MESS ['AUTH_BLOG_NEW_POST'] = "Post To Blog";
$MESS ['AUTH_BLOG_CREATE'] = "Create Blog";
$MESS ['AUTH_SONET_MESSAGES'] = "Personal Messages";
$MESS ['AUTH_HELLO'] = "Hello, ";
?>
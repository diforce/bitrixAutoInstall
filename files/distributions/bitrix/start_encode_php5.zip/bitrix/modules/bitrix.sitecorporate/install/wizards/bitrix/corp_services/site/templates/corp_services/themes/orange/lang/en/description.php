<?
$MESS["CPST_ORANGE"] = "Orange";
?>
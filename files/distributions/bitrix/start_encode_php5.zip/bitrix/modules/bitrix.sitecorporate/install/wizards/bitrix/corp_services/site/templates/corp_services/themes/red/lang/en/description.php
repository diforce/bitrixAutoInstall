<?
$MESS["CPST_RED"] = "Red";
?>
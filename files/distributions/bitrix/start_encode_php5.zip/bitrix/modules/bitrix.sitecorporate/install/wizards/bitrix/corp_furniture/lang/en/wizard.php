<?
$MESS["wiz_structure_data"] = "Install Demo Data for Corporate Website";
$MESS["wiz_restructure_data"] = "Reinstall Demo Data for Corporate Website";
$MESS["WIZ_COMPANY_LOGO"] = "Logo (recommended size: 210 x 61)";
$MESS["WIZ_COMPANY_SLOGAN"] = "Company Slogan";
$MESS["WIZ_COMPANY_SLOGAN_DEF"] = "Company slogan<br />&nbsp;&nbsp;placeholder";
$MESS["WIZ_COMPANY_COPY"] = "Copyrights";
$MESS["WIZ_COMPANY_COPY_DEF"] = "<p>&copy; 2001-2013 &laquo;Company name&raquo;</p><p>Address</p><p><b>Phone</b></p>";
$MESS["wiz_site_name"] = "Corporate Website";
$MESS["wiz_site_desc"] = "We use only the high quality equipment to manufacture our furniture to achieve the superior quality.";
$MESS["wiz_keywords"] = "sofas, chairs, office furniture, kitchen furniture, nursery furniture";
$MESS["wiz_meta_data"] = "Metadata:";
$MESS["wiz_meta_description"] = "Site Description:";
$MESS["wiz_meta_keywords"] = "Keywords:";
?>
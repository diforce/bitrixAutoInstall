<?
$sSectionName = "News";
$arDirProperties = Array(

);
?>
<?
$MESS["AUTH_FORGOT_PASSWORD_1"] = "Forgot your password? Enter your login or e-mail.<br />The password change instructions and your registration data will be sent to your e-mail.";
$MESS["AUTH_SEND"] = "Send";
$MESS["AUTH_AUTH"] = "Authorization";
$MESS["AUTH_LOGIN"] = "Login";
?>
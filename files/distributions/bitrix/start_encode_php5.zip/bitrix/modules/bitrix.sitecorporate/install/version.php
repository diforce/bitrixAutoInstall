<?
$arModuleVersion = array(
	"VERSION" => "12.5.0",
	"VERSION_DATE" => "2013-03-19 9:00:00"
);
?>
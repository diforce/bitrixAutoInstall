<?$arTemplate = Array(
	"NAME"=>GetMessage('CFST_TEMPLATE_NAME'), 
	"DESCRIPTION"=>GetMessage('CFST_TEMPLATE_DESC')
);?>
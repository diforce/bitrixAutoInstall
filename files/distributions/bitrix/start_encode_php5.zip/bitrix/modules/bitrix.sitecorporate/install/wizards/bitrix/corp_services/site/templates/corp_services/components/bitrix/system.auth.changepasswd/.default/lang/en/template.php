<?
$MESS ['AUTH_CHANGE_PASSWORD'] = "Change Password";
$MESS ['AUTH_LOGIN'] = "Login";
$MESS ['AUTH_CHECKWORD'] = "Check Word";
$MESS ['AUTH_NEW_PASSWORD'] = "New Password";
$MESS ['AUTH_NEW_PASSWORD_CONFIRM'] = "Confirm Password";
$MESS ['AUTH_CHANGE'] = "Change Password";
$MESS ['AUTH_REQ'] = "Required Fields";
$MESS ['AUTH_AUTH'] = "Authorization";
$MESS ['AUTH_NEW_PASSWORD_REQ'] = "New Password";
?>
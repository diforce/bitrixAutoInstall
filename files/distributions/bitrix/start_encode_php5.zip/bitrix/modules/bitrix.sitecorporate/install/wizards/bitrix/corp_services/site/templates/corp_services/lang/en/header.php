<?
$MESS["HDR_GOTO_MAIN"] = "Main Page";
$MESS["HDR_ASK"] = "Feedback";
?>
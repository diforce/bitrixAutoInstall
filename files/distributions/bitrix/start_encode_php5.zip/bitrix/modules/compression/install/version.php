<?
$arModuleVersion = array(
	"VERSION" => "11.0.0",
	"VERSION_DATE" => "2011-10-03 11:00:00"
);
?>
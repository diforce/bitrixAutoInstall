<?
$MESS ['LIBRARY'] = "Compression library";
$MESS ['NOT_COMPRESSED'] = "page size";
$MESS ['COMPRESSED'] = "compressed";
$MESS ['COEFFICIENT'] = "compression ratio";
?>
